
#include "VerdiRayCastStrategy.h"
#include "VerdiRayCastStrategyImpl.h"

namespace Verdi {

	RayCastStrategy::RayCastStrategy(const String& shaderPath)
	{
		mpImpl = new RayCastStrategy(shaderPath);
	}

	RayCastStrategy::~RayCastStrategy()
	{
		delete mpImpl;
	}

	void RayCastStrategy::initialise(uint32_t width, uint32_t height)
	{
		mpImpl->initialise(width,height);
	}

	void RayCastStrategy::contextChanged(const RenderContext* newContext)
	{
		mpImpl->contextChanged(newContext);
	}

	void RayCastStrategy::beginFrame(float dt, float time)
	{
		mpImpl->beginFrame(dt,time);
	}

	void RayCastStrategy::endFrame()
	{
		mpImpl->endFrame();
	}

	void RayCastStrategy::render()
	{
		mpImpl->render();
	}

	void RayCastStrategy::resize(uint32_t width, uint32_t height)
	{
		mpImpl->resize(width,height);
	}

	void RayCastStrategy::shutdown()
	{
		mpImpl->shutdown();
	}

	void RayCastStrategy::awake()
	{
		mpImpl->awake();
	}

	void RayCastStrategy::suspend()
	{
		mpImpl->suspend();
	}

	bool RayCastStrategy::isInitialised() const
	{
		return mpImpl->isInitialised();
	}
}