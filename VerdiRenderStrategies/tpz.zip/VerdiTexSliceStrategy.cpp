
#include "VerdiTexSliceStrategy.h"
#include "VerdiTexSliceStrategyImpl.h"

namespace Verdi {

	TexSliceStrategy::TexSliceStrategy(const String& shaderPath)
	{
		mpImpl = new TexSliceStrategy(shaderPath);
	}

	TexSliceStrategy::~TexSliceStrategy()
	{
		delete mpImpl;
	}

	void TexSliceStrategy::initialise(uint32_t width, uint32_t height)
	{
		mpImpl->initialise(width,height);
	}

	void TexSliceStrategy::contextChanged(const RenderContext* newContext)
	{
		mpImpl->contextChanged(newContext);
	}

	void TexSliceStrategy::beginFrame(float dt, float time)
	{
		mpImpl->beginFrame(dt,time);
	}

	void TexSliceStrategy::endFrame()
	{
		mpImpl->endFrame();
	}

	void TexSliceStrategy::render()
	{
		mpImpl->render();
	}

	void TexSliceStrategy::resize(uint32_t width, uint32_t height)
	{
		mpImpl->resize(width,height);
	}

	void TexSliceStrategy::shutdown()
	{
		mpImpl->shutdown();
	}

	void TexSliceStrategy::awake()
	{
		mpImpl->awake();
	}

	void TexSliceStrategy::suspend()
	{
		mpImpl->suspend();
	}

	bool TexSliceStrategy::isInitialised() const
	{
		return mpImpl->isInitialised();
	}

}