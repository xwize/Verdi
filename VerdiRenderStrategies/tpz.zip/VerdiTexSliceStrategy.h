
#ifndef __Verdi_Tex_Slice_Strategy_H__
#define __Verdi_Tex_Slice_Strategy_H__

#include "Verdi.h"

namespace Verdi {

	// Definition for hidden implementation
	class TexSliceStrategyImpl;

	/** Class that wraps the implementation strategy.
	*/
	class TexSliceStrategy : public RenderStrategy
	{
	protected:
		TexSliceStrategyImpl* mpImpl;
	public:

		/** Default constructor.
		*/
		TexSliceStrategy(const String& shaderPath ="shaders/TexSliceStrategy/TexSlice.cgfx");

		/** Default destructor.
		*/
		~TexSliceStrategy();

		// Interface implementation
		void initialise(uint32_t width, uint32_t height);
		void beginFrame(float dt, float time);
		void render();
		void endFrame();
		void shutdown();
		void contextChanged(const RenderContext* newContext);
		void suspend();
		void awake();
		void resize(uint32_t width, uint32_t height);
		bool isInitialised() const;
	};
}

#endif // __Verdi_Tex_Slice_Strategy_H__